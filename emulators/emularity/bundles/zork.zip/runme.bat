cd zork1
frotz.exe data/zork1.dat
